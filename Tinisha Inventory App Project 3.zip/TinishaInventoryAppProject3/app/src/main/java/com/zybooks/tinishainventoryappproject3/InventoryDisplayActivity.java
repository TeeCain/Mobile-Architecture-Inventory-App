package com.zybooks.tinishainventoryappproject3;


import static com.zybooks.tinishainventoryappproject3.R.id.nameEditText;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;


public class InventoryDisplayActivity extends AppCompatActivity {

    private InventoryDatabase inventoryDatabase;
    private GridView gridView;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory_display);

        // Initialize the database
        inventoryDatabase = new InventoryDatabase(this);
        gridView = findViewById(R.id.grid_view);

        // Update the grid view with the items from the database
        updateGridView();

        // Set click listener for grid items
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
                // TODO: Implement logic to change the quantity of the selected item
            }
        });

        // Set long click listener for grid items
        gridView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedItem = (String) parent.getItemAtPosition(position);
                int itemId = getItemIdFromSelectedItem(selectedItem);
                inventoryDatabase.deleteItem(itemId);
                updateGridView();
                return true;
            }
        });

        // Set click listener for "Add Item" button
        findViewById(R.id.floatingActionButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryDisplayActivity.this, AddItemActivity.class);
                startActivity(intent);
            }
        });

        // Set click listener for "Notification Settings" button
        findViewById(R.id.notificationSettings_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryDisplayActivity.this, NotificationSettingsActivity.class);
                startActivity(intent);
            }
        });

        // Set click listener for "Logout" button
        findViewById(R.id.logout_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(InventoryDisplayActivity.this, MainActivity.class);
                finish();
            }
        });
    }

    // Update the grid view with items from the database
    private void updateGridView() {
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, inventoryDatabase.getAllItems());
        gridView.setAdapter(adapter);
    }

    // Extract the item ID from the selected item string
    private int getItemIdFromSelectedItem(String selectedItem) {
        String[] parts = selectedItem.split(":");
        return Integer.parseInt(parts[1].trim());
    }
}
