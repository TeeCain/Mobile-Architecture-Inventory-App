package com.zybooks.tinishainventoryappproject3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class AddItemActivity extends AppCompatActivity {

    private InventoryDatabase inventoryDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        // Set click listener for the "Back" button
        findViewById(R.id.back_button).setOnClickListener(v -> {
            // Return to the InventoryDisplayActivity
            Intent intent = new Intent(AddItemActivity.this, InventoryDisplayActivity.class);
            finish();

            // Initialize the InventoryDatabase instance
            inventoryDatabase = new InventoryDatabase(this);

            // Set a click listener on the "Add Inventory" button
            findViewById(R.id.addInventory_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // Get the user input for item name, quantity, and date
                    EditText nameEditText = findViewById(R.id.nameEditText);
                    EditText quantityEditText = findViewById(R.id.quantityEditText);
                    EditText dateEditText = findViewById(R.id.dateEditText);

                    String name = nameEditText.getText().toString();
                    int quantity = Integer.parseInt(quantityEditText.getText().toString());
                    String date = dateEditText.getText().toString();

                    // Add the item to the inventory database
                    inventoryDatabase.addItem(name, quantity, date);

                    // Create an Intent to start the InventoryDisplayActivity
                    Intent intent = new Intent(AddItemActivity.this, InventoryDisplayActivity.class);
                    startActivity(intent);
                }


            });
        });

    }
}

