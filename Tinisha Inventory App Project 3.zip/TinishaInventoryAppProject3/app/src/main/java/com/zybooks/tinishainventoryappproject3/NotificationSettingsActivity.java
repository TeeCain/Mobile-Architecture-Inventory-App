package com.zybooks.tinishainventoryappproject3;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.Manifest;


public class NotificationSettingsActivity extends AppCompatActivity {

    // Request code for SMS permission
    private static final int PERMISSION_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_settings);

        // Set click listener for the "Back to Main" button
        findViewById(R.id.backToMain_button).setOnClickListener(v -> {
            // Return to the InventoryDisplayActivity
            Intent intent = new Intent(NotificationSettingsActivity.this, InventoryDisplayActivity.class);
            finish();

            // Set click listener for the "Request Permission" button
            Button buttonRequestPermission = findViewById(R.id.button_request_permission);
            buttonRequestPermission.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // Check if SMS permission is granted
                    if (ContextCompat.checkSelfPermission(NotificationSettingsActivity.this, Manifest.permission.SEND_SMS)
                            != PackageManager.PERMISSION_GRANTED) {
                        // Request SMS permission
                        ActivityCompat.requestPermissions(NotificationSettingsActivity.this, new String[]{Manifest.permission.SEND_SMS},
                                PERMISSION_REQUEST_CODE);
                    } else {
                        // Permission already granted
                        Toast.makeText(NotificationSettingsActivity.this, "Permission already granted.", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(this, "Permission granted. SMS alerts will be sent for low inventory.", Toast.LENGTH_SHORT).show();
            } else {
                // Permission denied
                Toast.makeText(this, "Permission denied. SMS alerts will not be sent for low inventory.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
