package com.zybooks.tinishainventoryappproject3;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.zybooks.tinishainventoryappproject3.ui.login.LoginActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Set click listener for the login button
        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Create an Intent to start the InventoryDisplayActivity
                Intent intent = new Intent(MainActivity.this, InventoryDisplayActivity.class);
                startActivity(intent);
            }
        });
    }
}

// TODO: Add inventory data to grid, set up notifications