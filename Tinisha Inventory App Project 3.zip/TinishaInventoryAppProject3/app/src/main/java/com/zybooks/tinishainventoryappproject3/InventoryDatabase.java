package com.zybooks.tinishainventoryappproject3;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class InventoryDatabase extends SQLiteOpenHelper {
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "InventoryDB";
    private static final String TABLE_INVENTORY = "inventory";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_QUANTITY = "quantity";
    private static final String KEY_DATE = "date";

    public InventoryDatabase(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Create the inventory table
        String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY + "("
                + KEY_ID + " INTEGER PRIMARY KEY,"
                + KEY_NAME + " TEXT,"
                + KEY_QUANTITY + " INTEGER,"
                + KEY_DATE + " TEXT" + ")";
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop the old table if it exists and create a new one
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // Add an item to the inventory
    public void addItem(String name, int quantity, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_QUANTITY, quantity);
        values.put(KEY_DATE, date);
        db.insert(TABLE_INVENTORY, null, values);
        db.close();
    }

    // Delete an item from the inventory
    public void deleteItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INVENTORY, KEY_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Update an item in the inventory
    public void updateItem(int id, String name, int quantity, String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_NAME, name);
        values.put(KEY_QUANTITY, quantity);
        values.put(KEY_DATE, date);
        db.update(TABLE_INVENTORY, values, KEY_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }

    // Get all items from the inventory
    public List<String> getAllItems() {
        List<String> itemsList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_INVENTORY;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                // Format the item information
                String item = "ID: " + cursor.getInt(0) +
                        ", Name: " + cursor.getString(1) +
                        ", Quantity: " + cursor.getInt(2) +
                        ", Date: " + cursor.getString(3);
                itemsList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        db.close();
        return itemsList;
    }
}
